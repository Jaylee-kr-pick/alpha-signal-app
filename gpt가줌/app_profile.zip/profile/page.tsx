
'use client';

export default function ProfilePage() {
  return (
    <div>
      <h2 className="text-lg font-bold mb-4">👤 프로필</h2>
      <p className="text-sm text-gray-600">
        사용자 정보를 여기에 표시합니다.
      </p>
    </div>
  );
}
