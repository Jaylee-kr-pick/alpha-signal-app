
'use client';

export default function SignalsPage() {
  return (
    <div>
      <h2 className="text-lg font-bold mb-4">📈 시그널 페이지</h2>
      <p className="text-sm text-gray-600">
        AI 기반 투자 시그널을 여기에 표시할 예정입니다.
      </p>
    </div>
  );
}
