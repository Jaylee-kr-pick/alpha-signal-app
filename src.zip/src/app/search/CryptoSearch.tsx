// CryptoSearch.tsx
export default function CryptoSearch() {
  return <div>코인 검색 기능 준비 중</div>;
}