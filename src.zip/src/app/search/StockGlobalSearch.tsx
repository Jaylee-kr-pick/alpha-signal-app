// StockGlobalSearch.tsx
export default function StockGlobalSearch() {
  return <div>해외주식 검색 기능 준비 중</div>;
}
