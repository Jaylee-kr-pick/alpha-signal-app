// src/app/layout.tsx
import './globals.css';
import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import Link from 'next/link';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'Alpha Signal App',
  description: 'AI 기반 투자 시그널 앱',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ko">
      <body className={`${inter.className} bg-gray-50 min-h-screen flex justify-center`}>
        <div className="w-[390px] min-h-screen relative pb-24 bg-white shadow-md">
          {/* 헤더 */}
          <header className="p-4 border-b border-gray-200 text-center font-bold text-lg flex justify-between items-center bg-white">
            <button className="text-2xl text-gray-700">☰</button>
            <span>Alpha Signal</span>
            <div className="w-6" />
          </header>

          {/* 본문 */}
          <main className="p-4 pb-24">
            {children}
          </main>

          {/* 공통 퀵바 */}
          <footer className="fixed bottom-0 left-1/2 -translate-x-1/2 w-[390px] bg-white border-t border-gray-200 flex justify-around py-2 text-xs">
            <Link href="/dashboard" className="text-gray-500 text-center">
              <div className="text-lg">⏱</div>
              <div>Dashboard</div>
            </Link>
            <div className="text-gray-500 text-center">
              <div className="text-lg">🗞</div>
              <div>News</div>
            </div>
            <div className="text-gray-500 text-center">
              <div className="text-lg">💹</div>
              <div>Signals</div>
            </div>
            <Link href="/watchlist" className="text-gray-500 text-center">
              <div className="text-lg">📌</div>
              <div>관심종목</div>
            </Link>
            <div className="text-gray-500 text-center">
              <div className="text-lg">👤</div>
              <div>프로필</div>
            </div>
          </footer>
        </div>
      </body>
    </html>
  );
}
