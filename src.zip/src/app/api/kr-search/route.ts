// src/app/api/kr-search/route.ts
import { NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';
import csv from 'csv-parser';

const STOCKS_PATH = path.resolve(process.cwd(), 'public/data/kr_stocks.csv');

type StockItem = {
  code: string;
  standardCode: string;
  name: string;
};

// "삼성전자     ST100..." → "삼성전자"로 정제
function cleanName(name: string): string {
  return name.replace(/\s+ST.*$/, '').trim();
}

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const query = searchParams.get('q')?.trim();

  if (!query) return NextResponse.json({ results: [] });

  const results: StockItem[] = [];

  return new Promise((resolve, reject) => {
    fs.createReadStream(STOCKS_PATH)
      .pipe(csv())
      .on('data', (row) => {
        try {
          const name = cleanName(row['한글명'] || '');
          if (
            name.includes(query) ||
            (row['단축코드'] && row['단축코드'].includes(query)) ||
            (row['표준코드'] && row['표준코드'].includes(query))
          ) {
            results.push({
              code: row['단축코드'],
              standardCode: row['표준코드'],
              name,
            });
          }
        } catch (err) {
          console.error('❌ row 파싱 에러:', err);
        }
      })
      .on('end', () => {
        resolve(NextResponse.json({ results }));
      })
      .on('error', (err) => {
        console.error('❌ CSV 파일 읽기 실패:', err);
        resolve(NextResponse.json({ results: [] }));
      });
  });
}